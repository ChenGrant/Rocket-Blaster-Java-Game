public class MainRocketBlaster {
	public static void main(String[] args) {
		Frame f = new Frame();
	}
}